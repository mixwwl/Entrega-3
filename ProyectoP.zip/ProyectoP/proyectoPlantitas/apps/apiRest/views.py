from django.shortcuts import render
from django.shortcuts import render
from django.views import View
from apps.models import *
from django.http import JsonResponse, HttpResponseBadRequest
# Create your views here.
# Create your views here.

from django.shortcuts import render
from django.views import View
from apps.models import *
from django.http import JsonResponse, HttpResponseBadRequest
# Create your views here.

class ObtenerProductos(View):
    def get(self, request):
        productos = Producto.objects.all()
        if productos:
            return  JsonResponse(list(productos.values()),safe=False)
        else:
            return HttpResponseBadRequest("Hubo un problema en la soclicitud")