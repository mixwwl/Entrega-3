from django.urls import path
from . import views

urlpatterns = [
    path('', views.cargarIndex, name='cargarIndex'),
    
    path('cargarCarrito/', views.cargarCarrito, name='cargarCarrito'),
    path('agregar_al_carrito/', views.agregar_al_carrito, name='agregar_al_carrito'),
    path('eliminar_producto_carrito/<int:producto_id>/', views.eliminar_producto_carrito, name='eliminar_producto_carrito'),
    
    path('catalogo.html', views.cargarCatalgo, name='cargarCatalogo'),
    
    path('iniciodesesion.html', views.cargarInicioSe, name='cargarInicioSesion'),
    
    path('lista.html', views.cargarLista, name='cargarLista'),
    
    path('modificar.html', views.cargarModificar, name='cargarModificar'),
    
    path('cargarAgregarProducto', views.cargarAgregarProducto, name='cargarAgregarProducto'),
    path('agregarProducto', views.agregarProducto),
    
    
    path('cargarEditarProducto/<id>',views.cargarEditarProducto),
    path('editarProducto',views.editarProducto),
    
     path('eliminarProducto/<id>',views.eliminarProducto),
    
    path('iniciarSesion/', views.iniciarSesion, name='iniciarSesion'),

]
