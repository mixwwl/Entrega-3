function consumirApi() {
    const apiKey = '83a25ac7289fabdc8ddfc912aceca729'; // Reemplaza con tu clave de API de OpenWeatherMap
    const ciudad = 'Santiago'; // Reemplaza con la ciudad de tu elección

    fetch(`https://api.openweathermap.org/data/2.5/weather?q=${ciudad}&appid=${apiKey}&units=metric`)
        .then(response => response.json())
        .then(data => {
            console.log("Informacion API del Clima", data);

            const climaInfo = document.getElementById("climaInfo");

            // Verificar si 'main' y 'temp' están presentes en la respuesta
            if (data.main && data.main.temp) {
                climaInfo.innerHTML = `Clima en ${ciudad}: ${data.main.temp}°C, ${data.weather[0].description}`;
            } else {
                climaInfo.innerHTML = "No se pudo obtener la información del clima.";
            }
        })
        .catch(error => {
            console.error("Error al consumir la API del Clima", error);
            const climaInfo = document.getElementById("climaInfo");
            climaInfo.innerHTML = `Error al obtener la información del clima. Detalles del error: ${error.message}`;
        });
}

// Llamamos a la función al cargar la página
document.addEventListener('DOMContentLoaded', function () {
    consumirApi();
});

