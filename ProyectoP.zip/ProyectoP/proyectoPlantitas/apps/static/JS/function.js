function validar(){
 
}



const formularioAgregar = document.getElementById("formAgregar");

formularioAgregar.addEventListener('submit',function(evento){
    evento.preventDefault();

    var sku = document.getElementById("txtSku").value;

    if (sku.length == 0) {
        console.log("111");
        alert("Debe ingresar un SKU.");
        return;
    }else{
        this.submit();
    }

})


