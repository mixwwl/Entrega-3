/* Ventanilla Inicio Sesion*/
function abrirIniciarSesion() {
    const abrirmodal1 = document.querySelector("#modal");

    abrirmodal1.showModal();
    
}


function cerrarIniciarSesion() {
    const cerrarmodal1 = document.querySelector("#modal");

    cerrarmodal1.close();
    
}




/*
const abrirm = document.getElementById("modala");
const cerrarm = document.getElementById("modalc");
const cerrarm2 = document.getElementById("btbt");
const modal = document.getElementById("modal");

abrirm.addEventListener("click",()=>{
    modal.showModal();
})

cerrarm.addEventListener("click",()=>{
    modal.close();
})

cerrarm2.addEventListener("click",()=>{
    modal.close();
})*/