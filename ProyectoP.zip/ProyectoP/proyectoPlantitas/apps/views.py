from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test, permission_required
from django.contrib.auth import authenticate, login, logout
from .models import Producto, Categoria, Carrito
import os
from django.conf import settings
from cryptography.fernet import Fernet
from django.http import HttpResponse

# Create your views here.



    


def cargarIndex(request):
    return render(request,"index.html")

def menu(request):
    return render(request,"menu.html")

@login_required
def cargarCarrito(request):
    if request.user.is_authenticated:
        carrito = Carrito.objects.filter(usuario=request.user)
    else:
        carrito = None

    return render(request, 'Carrito.html', {'carrito': carrito})


def agregar_al_carrito(request):
    if request.method == 'POST':
        producto_id = request.POST.get('producto_id')
        cantidad = request.POST.get('cantidad')

        if cantidad is not None:
            cantidad = int(cantidad)

            producto = Producto.objects.get(id_producto=producto_id)

            if cantidad <= producto.stock:
                cantidad_disminuir = min(cantidad, int(producto.stock * 0.8))  # Tope máximo del 80%
                producto.stock -= cantidad_disminuir  # Restar la cantidad disminuida al stock
                producto.save()  # Guardar los cambios en la base de datos

                carrito, creado = Carrito.objects.get_or_create(usuario=request.user, producto=producto)
                carrito.cantidad += cantidad_disminuir  # Añadir la cantidad disminuida al carrito
                carrito.save()
    return redirect('cargarCarrito')

def eliminar_producto_carrito(request, producto_id):
    if request.method == 'POST':
        carrito = Carrito.objects.filter(usuario=request.user, producto_id=producto_id).first()
        if carrito:
            carrito.delete()
    return redirect('cargarCarrito')




@login_required
def cargarAgregarProducto(request):
    categorias = Categoria.objects.all()
    productos = Producto.objects.all()
    return render(request,"agregarProducto.html", {"categoriasTodas":categorias, "productsAll":productos})

@login_required
def agregarProducto(req):
    #print("ELEMENTOS EN LA REQUEST ", req.POST)
    v_sku = req.POST['txtSku']
    v_nombre = req.POST['txtNombre']
    v_precio = req.POST['txtPrecio']
    v_stock = req.POST['txtStock']
    v_descripcion = req.POST['txtDescripcion']
    v_imagen = req.FILES['txtImagen']
    v_categoria = Categoria.objects.get(id_categoria = req.POST['cmbCategoria'])



    Producto.objects.create(
        id_producto = v_sku,
        nombre = v_nombre,
        precio = v_precio,
        stock = v_stock,
        descripcion = v_descripcion,
        imagen = v_imagen,
        categoria = v_categoria
    )
    
    messages.success(req, '¡Agregado exitosa!')

    return redirect('cargarAgregarProducto')




def cargarEditarProducto(request,id):
    categorias = Categoria.objects.all()
    producto = Producto.objects.get(id_producto = id)
    categoriaId = producto.categoria
    productoCategoriaId = Categoria.objects.get(id_categoria = categoriaId.id_categoria).id_categoria
    
    
    return render(request, "editarProducto.html",{"producto":producto, "categorias":categorias ,"categoriaId":productoCategoriaId})


def editarProducto(req):
    print("ELEMENTOS EN LA REQUEST  -.-------->>>>>>>>", req.POST)
    v_sku = req.POST['txtSku']
    productoBD = Producto.objects.get(id_producto = v_sku)
    v_nombre = req.POST['txtNombre']
    v_precio = req.POST['txtPrecio']
    v_stock = req.POST['txtStock']
    v_descripcion = req.POST['txtDescripcion']
    v_categoria = Categoria.objects.get(id_categoria = req.POST['cmbCategoria'])

    try:
        v_imagen = req.FILES['txtImagen']   
        ruta_imagen = os.path.join(settings.MEDIA_ROOT, str(productoBD.imagen))
        os.remove(ruta_imagen)
    except:
        v_imagen = productoBD.imagen

    productoBD.nombre = v_nombre
    productoBD.precio = v_precio
    productoBD.stock = v_stock
    productoBD.descripcion = v_descripcion
    productoBD.categoria = v_categoria
    productoBD.imagen = v_imagen
    productoBD.save()
    
    messages.success(req, '¡Modificacion exitosa!')
    return redirect('/cargarAgregarProducto')


def eliminarProducto(request,id):
    producto = Producto.objects.get(id_producto = id)
    producto.delete()
    ruta_imagen = os.path.join(settings.MEDIA_ROOT, str(producto.imagen))
    os.remove(ruta_imagen)
    messages.success(request, '¡Producto Eliminado!')
    return redirect('/cargarAgregarProducto')


@login_required
def iniciarSesion(request):
    if request.method == 'POST':
        username = request.POST['txtEmailSesion']
        password = request.POST['txtPassword3']
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('cargarAgregarProducto')
        else:
            messages.error(request, 'Credenciales inválidas. Inténtalo de nuevo.')

    return redirect('cargarInicioSesion')


def cerrarSesion(request):
    logout(request)
    return redirect('cargarInicioSesion')




def cargarCatalgo(request):
    return render(request,"catalogo.html")

def cargarInicioSe(request):
    return render(request,"iniciodesesion.html")

def cargarLista(request):
    categorias = Categoria.objects.all()
    productos = Producto.objects.filter(stock__gt=0)  # Filtrar productos con stock mayor a 0
    
    return render(request, "lista.html", {"categoriasTodas": categorias, "productsAll": productos})


def cargarModificar(request):
    return render(request,"modificar.html")

def encrypt():
    key = Fernet.generate_key()
    print("LLAVE b",key)

#def add(request):
    #data = {
     #   'form' : ProductoForm()
    #}

    #if request.method == 'POST':
        #formulario = ProductoForm(request.POST, files=request.FILES) # OBTIENE LA DATA DEL FORMULARIO
       # if formulario.is_valid():
      #      formulario.save() # INSERT INTO.....
            #data['msj'] = "Producto guardado correctamente"
     #       messages.success(request, "Producto almacenado correctamente")
        #else:
            #messages.success(request, "FFFFFFFFFFFF")
            
    #return render(request, 'core/add-product.html', data)


#@permission_required('core.update-product')
#def update(request, id):
    #producto = Producto.objects.get(id=id) # OBTIENE UN PRODUCTO POR EL ID
    #data = {
     #   'form' : ProductoForm(instance=producto) # CARGAMOS EL PRODUCTO EN EL FORMULARIO
    #}

    #if request.method == 'POST':
        #formulario = ProductoForm(data=request.POST, instance=producto, files=request.FILES) # NUEVA INFORMACION
        #if formulario.is_valid():
        #    formulario.save() # INSERT INTO.....
       #     #data['msj'] = "Producto actualizado correctamente"
      #      messages.success(request, "Producto modificado correctamente")
     #       data['form'] = formulario # CARGA LA NUEVA INFOR EN EL FORMULARIO

    #return render(request, 'core/update-product.html', data)



#@permission_required('core.delete')
#def delete(request, id):
  #  producto = Producto.objects.get(id=id) # OBTIENE UN PRODUCTO POR EL ID
 #   producto.delete()

#    return redirect(to="index")


#def vaciar_carrito(request):
    #productos_carrito = Carrito.objects.filter()

    # Actualiza el stock de cada producto en base a la cantidad del carrito
    #for producto_carrito in productos_carrito:
       # producto = producto_carrito.producto
      #  cantidad_agregada = producto_carrito.cantidad_agregada

        # Resta la cantidad del carrito al stock del producto
      #  producto.stock -= cantidad_agregada
     #   producto.save()

    # Elimina todos los registros del carrito del usuario actual
    #productos_carrito.delete()

    #return redirect('index')  # Redireccionar a la página de inicio después de vaciar el carrito
 
#def checkout(request):
    #carrito = Carrito.objects.all()
    #respuesta2 = requests.get('https://mindicador.cl/api/dolar').json()
    #valor_usd = respuesta2['serie'][0]['valor']
   # total_precio = sum(item.producto.precio * item.cantidad_agregada for item in carrito)
  #  total_precio = round(total_precio/valor_usd,2)
   # for item in carrito:
  #      item.total_producto = item.producto.precio * item.cantidad_agregada

   # datos = { 
   #     'listarproductos': carrito, 
   #     'total_precio' : total_precio
    #}
   # return render(request, 'core/checkout.html', datos)

#@login_required
#def seguimiento(request):
   # seguimientos = Seguimiento.objects.all()

   # total_precio = sum(item.precio_producto * item.cantidad_agregada for item in seguimientos)

   # for seguimiento in seguimientos:
    #    seguimiento.total_producto = seguimiento.precio_producto * seguimiento.cantidad_agregada

    #datos = {
    #    'seguimientos': seguimientos,
    #    'total_precio': total_precio
    #}

    #return render(request, 'core/seguimiento.html', datos)



#def shopgrid(request):
    #productosAll = Producto.objects.all()
    #page = request.GET.get('page', 1) # OBTENEMOS LA VARIABLE DE LA URL, SI NO EXISTE NADA DEVUELVE 1
    
    
   # try:
      #  paginator = Paginator(productosAll, 5)
      #  productosAll = paginator.page(page)
    #except:
      #  raise Http404

   # data = {
    #    'listado': productosAll,
     #   'paginator': paginator
    #}    
    #return render(request, 'core/shop-grid.html', data)





##def shopdetails(request,id):
    
    #producto = Producto.objects.get(id=id)
    #data = {'Productos': producto}

    #if request.method == 'POST':
       # tipo = TipoProducto()
      #  tipo.tipo = request.POST.get('tipo')
     #   producto2 = Producto()
      #  producto2.id = producto.id
       # producto2.nombre = request.POST.get('nombre')
     #   producto2.precio = request.POST.get('precio')
    #    producto2.stock = request.POST.get('stock')
     #   producto2.descripcion = request.POST.get('descripcion')
       # producto2.tipo = tipo
      #  producto2.vencimiento = request.POST.get('vencimiento')
     #   producto2.imagen = request.POST.get('imagen')
    #    producto2.vigente = request.POST.get('vigente')
       # producto2.cantidad_agregada = int(request.POST.get('cantidad_agregada', 1))
       # carrito = Carrito()
      #  carrito.producto_id = producto2.id
        #carrito.save()
       # messages.success(request, "Producto almacenado correctamente")
    
    #return render(request, 'core/shop-details.html', data)

#def shopdetails(request, id):
    #producto = Producto.objects.get(id=id)
    #data = {'Productos': producto}

    #if request.method == 'POST':
     #   carrito, created = Carrito.objects.get_or_create(producto=producto)
      #  cantidad_agregada = int(request.POST.get('cantidad_agregada', 1))
       # if not created:
        #    carrito.cantidad_agregada += cantidad_agregada
        #else:
         #   carrito.cantidad_agregada = cantidad_agregada
        #carrito.save()
        #messages.success(request, "Producto almacenado correctamente")

    #return render(request, 'core/shop-details.html', data)




#carrito
# shoping es donde se almacena cuando aniadimos al carrito 
#def shopingcart(request):
    #carrito = Carrito.objects.all()
    #total_precio = sum(item.producto.precio * item.cantidad_agregada for item in carrito)

    #for item in carrito:
    #    item.total_producto = item.producto.precio * item.cantidad_agregada

   # datos = { 
    #    'listarproductos': carrito, 
    #    'total_precio' : total_precio
    #}

    #return render(request, 'core/shoping-cart.html', datos)



#def eliminar_producto(request, id):
    #carro = Carrito.objects.get(id=id)
    #carro.delete()
    #return redirect("shopingcart")
    
#def registro(request):
   # data = {
  #      'form': CustomUserCreationForm()
   # }
    #if request.method == 'POST':
       # formulario = CustomUserCreationForm(data=request.POST)
        #if formulario.is_valid():
            #formulario.save()
            #user = authenticate(username=formulario.cleaned_data["username"], password=formulario.cleaned_data["password1"])
            #grupo = Group.objects.get(name="Cliente")
            #user.groups.add(grupo)
           # login(request, user)
          #  messages.success(request, "Te has registrado correctamente")
            #redirigir al home
         #   return redirect(to="index")
        #data["form"] = formulario    
    #return render(request, 'registration/registro.html',data) 